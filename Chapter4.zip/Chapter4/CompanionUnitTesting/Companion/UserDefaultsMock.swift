//
//  UserDefaults.swift
//  Horoscope
//
//  Created by Lakshmi Bomma on 10/3/16.
//  Copyright © 2016 RIIS. All rights reserved.
//


import Foundation

class UserDefaultsMock
{
    var standardUserDefaults :UserDefaults?
}


