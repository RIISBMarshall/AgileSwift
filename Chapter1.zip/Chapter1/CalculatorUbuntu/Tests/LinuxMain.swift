import XCTest
@testable import CalculatorTests

XCTMain([
    testCase(CalculatorTests.allTests)
])
