import PackageDescription
 
let package = Package(
    name: "Calculator"
)