import XCTest
@testable import chapter1Tests

XCTMain([
     testCase(chapter1Tests.allTests),
])
