struct chapter1 {

    var text = "Hello, World!"
}
